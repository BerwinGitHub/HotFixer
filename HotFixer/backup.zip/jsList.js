// GENERATED CODE -- DO NOT EDIT! 
var jsList = [
    "src/framework/AppDelegate.js",
    "src/framework/a_mod/moduleJs.js",
    "src/framework/a_mod/_metadata.js",
    "src/framework/a_mod/_metadataManager.js",
    "src/framework/frame/consoleframe.js",
    "src/framework/frame/Frame.js",
    "src/framework/game/FDirector.js",
    "src/framework/game/Game.js",
    "src/framework/game/GameScene.js",
    "src/framework/network/SocketHelper.js",
    "src/framework/protobuf/bytebuffer.js",
    "src/framework/protobuf/long.js",
    "src/framework/protobuf/protobuf.js",
    "src/framework/protobuf/ProtoHelper.js",
    "src/game/frames/HallFrame.js",
    "src/game/frames/HomeFrame.js",
    "src/language.js",
    "src/resource.js"
]