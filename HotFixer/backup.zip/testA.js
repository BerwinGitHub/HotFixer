/**
 * Created by Berwin on 2017/4/19.
 */
$include($import.framework.package.testB.TestB);
$include($import.framework.package.testC.TestC);

$class("TestA", ($export, TestB, TestC) => {

    var logA = function () {
        TestB.logB();
        TestC.logC();
    };
    $export.logA = logA;
});