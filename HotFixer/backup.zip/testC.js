/**
 * Created by Berwin on 2017/4/21.
 */
$include($import.framework.package.testB.TestB);

$class("TestC", ($export, TestB) => {

    var logC = function () {
        console.log("log C");
    };
    $export.logC = logC;
});