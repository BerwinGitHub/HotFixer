/**
 * Created by Berwin on 2017/4/19.
 */

$include($import.framework.package.testC.TestC);

$class("TestB", ($export, TestC) => {

    var logB = function () {
        TestC.logC();
    };
    $export.logB = logB;
});