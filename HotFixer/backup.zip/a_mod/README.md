# 包(模块管理)管理工具类

## WebStorm 文件模板
File->Settings->Editor->File and Code Templates

    /**
    * Created by ${USER} on ${DATE}.
    */
    ["mod ${Mod}"];
    ["import "];

    defmod("${Mod}",function (exp) {
        
    })