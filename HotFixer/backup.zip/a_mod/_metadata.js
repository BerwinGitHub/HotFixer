////这里是所有 元数据,由createMeta.py生成
var _$metadata={"src/framework/a_mod/README.md": ["mod ${Mod}", "import "]}